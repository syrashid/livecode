class Router
  def initialize(attr = {})
    # Store ALL controllers in instance variables
    # so that I can use them throughout the Router
    @meals_controller = attr[:meals_controller]
    @customers_controller = attr[:customers_controller]
    @sessions_controller = attr[:sessions_controller]
    @running = true
  end

  def run
    puts "Welcome to the Le Wagon Pub!"
    puts "----------------------------"
    while @running
      # First step is to check whether or not the current
      # user is an employee of the restaurant
      @current_user = @sessions_controller.login
      # We implement this second loop to allow for a user to logout and return back to the session login prompts
      while @current_user
        # Depending on role we will render different actions for the user to choose from, a la role based access
        if @current_user.manager?
          route_manager_action
        else
          route_delivery_guy_action
        end
      end
      print `clear`
    end
  end

  private

  # Our two routing options based off the role
  def route_manager_action
    print_manager_menu
    choice = gets.chomp.to_i
    print `clear`
    manager_action(choice)
  end

  def route_delivery_guy_action
    print_delivery_guy_menu
    choice = gets.chomp.to_i
    print `clear`
    delivery_guy_action(choice)
  end

  # Our two option printing methods
  def print_manager_menu
    puts "--------------------"
    puts "---- MGR MENU 🧔 ---"
    puts "--------------------"
    puts "1. Add new meal"
    puts "2. List all meals"
    puts "3. Add new customer"
    puts "4. List all customers"
    puts "7. Logout"
    puts "8. Exit"
    print "> "
  end

  def print_delivery_guy_menu
    # TODO
  end

  # Dispatch the User REQUEST to the
  # SPECIFIC controller action/method
  # that implements what the User wants to do
  def manager_action(choice)
    case choice
    when 1 then @meals_controller.add
    when 2 then @meals_controller.list
    when 3 then @customers_controller.add
    when 4 then @customers_controller.list
    when 7 then logout!
    when 8 then stop!
    else puts "Try again..."
    end
  end

  def delivery_guy_action(choice)
    # TODO
  end

  def logout!
    # TODO
  end

  def stop!
    logout!
    @running = false
  end
end
