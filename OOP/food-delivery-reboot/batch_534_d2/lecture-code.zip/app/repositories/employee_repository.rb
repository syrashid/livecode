require 'csv'
require_relative './base_repository'
require_relative '../models/employee'

class EmployeeRepository < BaseRepository

  def find_by_username(username)
    @elements.find { |element| element.username == username }
  end

  private

  def load_csv
    csv_options = { headers: :first_row, header_converters: :symbol }
    CSV.foreach(@csv_file, csv_options) do |row|
      # Translation Step
      row[:id] = row[:id].to_i
      @elements << Employee.new(row)
    end
    @next_id = @elements.last.id + 1 unless @elements.empty?
  end
end
