require "csv"
require_relative "../models/meal"
require_relative "./base_repository"

class MealRepository < BaseRepository

  private

  def load_csv
    csv_options = { headers: :first_row, header_converters: :symbol }

    CSV.foreach(@csv_file, csv_options) do |row|
      row[:id] = row[:id].to_i
      row[:price] = row[:price].to_i

      @elements << Meal.new(row)
    end

    @next_id = @elements.last.id + 1 unless @elements.empty?
  end
end
