require_relative './base_view'

class MealsView < BaseView; end
