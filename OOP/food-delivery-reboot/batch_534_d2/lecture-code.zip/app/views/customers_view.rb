require_relative './base_view'

class CustomersView < BaseView; end
